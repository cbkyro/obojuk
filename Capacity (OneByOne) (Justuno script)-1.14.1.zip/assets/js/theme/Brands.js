import PageManager from '../PageManager';

export default class Brands extends PageManager {
  constructor() {
    super();
  }
}
