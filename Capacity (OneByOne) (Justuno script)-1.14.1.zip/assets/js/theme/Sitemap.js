import PageManager from '../PageManager';

export default class SiteMap extends PageManager {
  constructor() {
    super();
  }
}
