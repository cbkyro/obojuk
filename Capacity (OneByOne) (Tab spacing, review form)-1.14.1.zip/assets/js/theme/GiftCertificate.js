import GiftCertificate from './core/GiftCertificate';

export default GiftCertificate;
