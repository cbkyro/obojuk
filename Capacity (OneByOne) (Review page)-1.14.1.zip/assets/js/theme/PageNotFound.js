import PageManager from '../PageManager';

export default class PageNotFound extends PageManager {
  constructor() {
    super();
  }
}
