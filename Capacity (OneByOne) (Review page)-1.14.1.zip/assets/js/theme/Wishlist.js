import PageManager from '../PageManager';

export default class WishList extends PageManager {
  constructor() {
    super();
  }
}
