import PageManager from '../PageManager';

export default class ContactUs extends PageManager {
  constructor() {
    super();
  }
}
