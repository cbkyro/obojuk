import PageManager from '../PageManager';

export default class OrderComplete extends PageManager {
  constructor() {
    super();
  }
}
