import PageManager from '../PageManager';

export default class Rss extends PageManager {
  constructor() {
    super();
  }
}
